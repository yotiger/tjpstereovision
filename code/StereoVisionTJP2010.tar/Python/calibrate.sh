#!/bin/bash

python ./chessboard_data.py
python ./stereocalibrate.py
python ./stereorectify.py
